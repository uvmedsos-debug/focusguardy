package com.shim.guard

import android.content.Context
import android.net.Uri
import java.io.File

/** File animasi dan suara yang kamu unggah sendiri. Disalin ke penyimpanan privat aplikasi. */
object Assets {
    class Slot(val key: String, val label: String, val mime: String, val maxMb: Int)

    private val kinds = listOf(
        "REST" to "Istirahat",
        "WORK" to "Kerja",
        "SOON" to "5 menit lagi",
        "WARN" to "Peringatan malam"
    )

    val slots: List<Slot> = buildList {
        add(Slot("bgm", "Musik latar scene", "audio/*", 25))
        for ((k, n) in kinds) add(Slot("img_$k", "Animasi · $n", "image/*", 10))
        for ((k, n) in kinds) add(Slot("voice_$k", "Suara · $n", "audio/*", 15))
        add(Slot("voice_TEMPT", "Suara · Saat mencoba buka game", "audio/*", 15))
    }

    private fun dir(c: Context) = File(c.filesDir, "assets").apply { mkdirs() }

    fun file(c: Context, key: String): File? =
        File(dir(c), key).takeIf { it.isFile && it.length() > 0 }

    /** Mengembalikan pesan error, atau null kalau berhasil. */
    fun import(c: Context, uri: Uri, slot: Slot): String? {
        return try {
            val tmp = File(dir(c), slot.key + ".tmp")
            val max = slot.maxMb * 1024L * 1024L
            var total = 0L
            c.contentResolver.openInputStream(uri)?.use { input ->
                tmp.outputStream().use { out ->
                    val buf = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buf)
                        if (n < 0) break
                        total += n
                        if (total > max) {
                            tmp.delete()
                            return "File terlalu besar (maks ${slot.maxMb} MB)."
                        }
                        out.write(buf, 0, n)
                    }
                }
            } ?: return "File tidak bisa dibuka."
            val dest = File(dir(c), slot.key)
            dest.delete()
            if (!tmp.renameTo(dest)) return "Gagal menyimpan."
            null
        } catch (e: Exception) {
            "Gagal: ${e.message}"
        }
    }

    fun remove(c: Context, key: String) {
        File(dir(c), key).delete()
    }
}
