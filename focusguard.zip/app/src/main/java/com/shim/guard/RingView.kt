package com.shim.guard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Typeface
import android.view.View

/**
 * Cincin kemajuan fase: busur terisi = seberapa jauh fase ini berjalan.
 * Digambar statis (tanpa animasi), hanya digambar ulang sekali per menit.
 */
class RingView(c: Context) : View(c) {

    var progress = 0f
    var accent = Pal.REST
    var top = ""
    var big = ""
    var small = ""

    private val d = resources.displayMetrics.density
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
    }
    private val capsPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        letterSpacing = 0.25f
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
    private val bigPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        typeface = Typeface.create("sans-serif-thin", Typeface.NORMAL)
    }
    private val smallPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        textAlign = Paint.Align.CENTER
        color = Pal.DIM
    }

    override fun onMeasure(w: Int, h: Int) {
        val size = minOf(MeasureSpec.getSize(w), (300 * d).toInt())
        setMeasuredDimension(size, size)
    }

    override fun onDraw(c: Canvas) {
        val th = 5 * d
        val rect = RectF(th, th, width - th, height - th)
        arc.strokeWidth = th

        arc.color = Pal.TRACK
        c.drawArc(rect, 0f, 360f, false, arc)
        arc.color = accent
        c.drawArc(rect, -90f, 360f * progress.coerceIn(0.01f, 1f), false, arc)

        val scale = minOf(1f, width / (280 * d))
        val cy = height / 2f
        val bigSize = 64 * d * scale

        capsPaint.textSize = 11 * d
        capsPaint.color = accent
        c.drawText(top, width / 2f, cy - bigSize * 0.58f, capsPaint)

        bigPaint.textSize = bigSize
        bigPaint.color = accent
        c.drawText(big, width / 2f, cy + bigSize * 0.30f, bigPaint)

        smallPaint.textSize = 13 * d
        c.drawText(small, width / 2f, cy + bigSize * 0.80f, smallPaint)
    }
}
