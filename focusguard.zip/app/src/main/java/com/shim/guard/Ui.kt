package com.shim.guard

import android.app.Activity
import android.graphics.Typeface
import android.widget.TextView

/** Pembantu tampilan hemat daya: hitam murni, tanpa animasi, dan laju segar rendah untuk layar statis. */
object Ui {
    fun dp(a: Activity, x: Int) = (x * a.resources.displayMetrics.density).toInt()

    /**
     * refreshRate: 30 untuk layar statis (lebih sedikit frame digambar),
     * 60 untuk layar yang bisa digulir supaya tetap halus.
     */
    fun lowPower(a: Activity, refreshRate: Float) {
        a.window.statusBarColor = Pal.BG
        a.window.navigationBarColor = Pal.BG
        val lp = a.window.attributes
        lp.preferredRefreshRate = refreshRate
        a.window.attributes = lp
    }

    /** Teks kecil huruf besar dengan jarak antar huruf. */
    fun caps(a: Activity, text: String, size: Float = 11f) = TextView(a).apply {
        this.text = text
        textSize = size
        letterSpacing = 0.25f
        setTextColor(Pal.DIM)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }
}
