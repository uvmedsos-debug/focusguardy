package com.shim.guard

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast

/** Pilih game yang dikunci. Menambah bebas kapan saja, melepas hanya di jendela admin. */
class GamesActivity : Activity() {

    private fun dp(x: Int) = Ui.dp(this, x)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.lowPower(this, 60f)   // daftar bisa digulir, jadi tetap halus

        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val chosen = Prefs.blocked(this).toMutableSet()
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedWith(compareByDescending<Pair<String, String>> { it.first in chosen }
                .thenBy { it.second.lowercase() })   // yang sudah dikunci tampil paling atas

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
            setPadding(dp(28), dp(28), dp(28), dp(16))
            setOnApplyWindowInsetsListener { v, i ->
                @Suppress("DEPRECATION")
                v.setPadding(dp(28), i.systemWindowInsetTop + dp(28), dp(28), i.systemWindowInsetBottom + dp(16))
                i
            }
        }
        root.addView(Ui.caps(this, "GAME  YANG  DIKUNCI"))
        root.addView(TextView(this).apply {
            val a = Schedule.admin
            text = "Menambah game boleh kapan saja. Melepas hanya jam " +
                "${Schedule.fmt(a.start)}-${Schedule.fmt(a.end)}."
            textSize = 13f
            setTextColor(Pal.DIM)
            setPadding(0, dp(10), 0, dp(12))
        })

        val list = ListView(this).apply {
            divider = null
            setSelector(android.R.color.transparent)
            cacheColorHint = Color.TRANSPARENT
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val on = apps[i].first in chosen
                return ((v as? TextView) ?: TextView(this@GamesActivity)).apply {
                    textSize = 17f
                    setPadding(0, dp(13), 0, dp(13))
                    text = (if (on) "●   " else "○   ") + apps[i].second
                    setTextColor(if (on) Pal.WORK else Pal.DIM)
                }
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (pkg in chosen) {
                // Melepas game dari daftar hanya boleh di jendela admin
                if (!Schedule.inAdmin(Schedule.nowSec())) {
                    val a = Schedule.admin
                    Toast.makeText(
                        this, "Terkunci. Game hanya bisa dilepas jam ${Schedule.fmt(a.start)}-${Schedule.fmt(a.end)}.",
                        Toast.LENGTH_LONG
                    ).show()
                    return@setOnItemClickListener
                }
                chosen.remove(pkg)
            } else {
                chosen.add(pkg)
            }
            Prefs.save(this, chosen)
            adapter.notifyDataSetChanged()
        }
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }
}
