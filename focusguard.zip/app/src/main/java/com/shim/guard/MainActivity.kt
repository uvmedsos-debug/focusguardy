package com.shim.guard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.LinearLayout
import android.widget.TextView

/**
 * Dasbor satu layar: cincin kemajuan fase, garis 24 jam, dan tiga tautan.
 * Hitam murni (dari tema), tanpa animasi, 30 Hz. Digambar ulang sekali per menit saat terlihat.
 */
class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var ring: RingView
    private lateinit var guard: TextView
    private lateinit var stats: TextView
    private lateinit var path: TextView
    private lateinit var tasks: TextView
    private lateinit var timeline: TimelineView

    private val refresh = object : Runnable {
        override fun run() {
            render()
            h.postDelayed(this, 60_000L - System.currentTimeMillis() % 60_000L + 50)
        }
    }

    private fun dp(x: Int) = Ui.dp(this, x)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.lowPower(this, 30f)

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(24), dp(28), dp(4))
            setOnApplyWindowInsetsListener { v, i ->
                @Suppress("DEPRECATION")
                v.setPadding(dp(28), i.systemWindowInsetTop + dp(24), dp(28), i.systemWindowInsetBottom + dp(4))
                i
            }
        }

        // baris atas: nama + status penjaga
        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        top.addView(Ui.caps(this, "FOCUS  GUARD"), LinearLayout.LayoutParams(0, -2, 1f))
        guard = Ui.caps(this, "", 11f).apply {
            letterSpacing = 0.1f
            setPadding(dp(12), dp(8), 0, dp(8))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        top.addView(guard)
        root.addView(top)

        // tengah: cincin + garis 24 jam
        ring = RingView(this)
        timeline = TimelineView(this)
        val mid = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            addView(ring, LinearLayout.LayoutParams(-2, -2))
            addView(timeline, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(12) })
        }
        root.addView(mid, LinearLayout.LayoutParams(-1, 0, 1f))

        // bawah: godaan + tugas
        stats = TextView(this).apply {
            textSize = 13f
            setTextColor(Pal.DIM)
            setPadding(0, dp(8), 0, dp(6))
        }
        tasks = TextView(this).apply {
            textSize = 15f
            setTextColor(Pal.TXT)
            setLineSpacing(0f, 1.2f)
            setPadding(0, dp(4), 0, dp(12))
        }
        path = TextView(this).apply {
            textSize = 12f
            setTextColor(Pal.DIM)
            setLineSpacing(0f, 1.2f)
            setPadding(0, 0, 0, dp(8))
        }
        root.addView(stats)
        root.addView(path)
        root.addView(tasks)

        // garis tipis + tiga tautan
        root.addView(View(this).apply { setBackgroundColor(Pal.TRACK) }, LinearLayout.LayoutParams(-1, 1))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun link(text: String, target: Class<*>) = Ui.caps(this, text, 12f).apply {
            setTextColor(Pal.TXT)
            gravity = Gravity.CENTER
            setPadding(0, dp(16), 0, dp(12))
            setOnClickListener { startActivity(Intent(this@MainActivity, target)) }
        }
        nav.addView(link("FOKUS", TasksActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(link("SUARA", AssetsActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        nav.addView(link("GAME", GamesActivity::class.java), LinearLayout.LayoutParams(0, -2, 1f))
        root.addView(nav)

        // tombol darurat sengaja kecil dan redup, supaya tidak terpencet tanpa sengaja
        root.addView(
            Ui.caps(this, "DARURAT", 10f).apply {
                gravity = Gravity.CENTER
                setPadding(0, dp(8), 0, dp(10))
                setOnClickListener { startActivity(Intent(this@MainActivity, EmergencyActivity::class.java)) }
            },
            LinearLayout.LayoutParams(-1, -2)
        )

        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        h.post(refresh)
    }

    override fun onPause() {
        h.removeCallbacks(refresh)
        super.onPause()
    }

    private fun render() {
        val now = Schedule.nowSec()
        val s = Schedule.status(now)
        val rem = Schedule.remaining(s.untilSec, now)

        ring.accent = if (s.open) Pal.REST else Pal.WORK
        ring.progress = Schedule.progress(now)
        ring.top = s.label.uppercase()
        ring.big = clock(rem)
        ring.small = if (s.open) "terkunci pukul ${Schedule.fmt(s.untilSec)}"
        else "dibuka pukul ${Schedule.fmt(s.untilSec)}"
        ring.invalidate()

        timeline.nowSec = now
        timeline.invalidate()

        val wk = Stats.week(this)
        stats.text = "Hari ini tergoda ${wk.last()}x   ${Stats.spark(wk)}"
        val msg = when {
            wk.last() >= 5 -> "Hari ini berat. Itu manusiawi. Kamu masih di jalur."
            Stats.winsToday(this) >= 1 -> "Kamu bertahan hari ini. Itu nyata."
            else -> ""
        }
        path.text = "Bertahan ${Stats.wins(this)}x  ·  ${Stats.days(this)} hari berjalan" +
            (if (msg.isEmpty()) "" else "\n$msg")
        path.visibility = if (Stats.days(this) > 0) View.VISIBLE else View.GONE
        val board = Tasks.board(this)
        tasks.text = board
        tasks.visibility = if (board.isEmpty()) View.GONE else View.VISIBLE

        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        guard.text = if (on) "●  aktif" else "○  mati  ·  ketuk"
        guard.setTextColor(if (on) Pal.REST else Pal.WARN)
    }

    /** Sisa waktu sebagai jam:menit, misalnya 2:14 */
    private fun clock(sec: Int): String {
        val m = (sec + 59) / 60
        return "%d:%02d".format(m / 60, m % 60)
    }
}
