package com.shim.guard

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

/**
 * Layar statis: latar hitam murni, tanpa animasi.
 * Hanya diperbarui sekali per menit dan hanya saat layar aplikasi terlihat.
 */
class MainActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private lateinit var title: TextView
    private lateinit var sub: TextView
    private lateinit var link: TextView
    private lateinit var timeline: TimelineView

    private val refresh = object : Runnable {
        override fun run() {
            render()
            h.postDelayed(this, 60_000L - System.currentTimeMillis() % 60_000L + 50)
        }
    }

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        letterSpacing = 0.25f
        setTextColor(Pal.DIM)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG

        if (Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        }

        // daftar aplikasi
        val pm = packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .filter { it.first != packageName }
            .distinctBy { it.first }
            .sortedBy { it.second.lowercase() }
        val chosen = Prefs.blocked(this).toMutableSet()

        // tampilan
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Pal.BG)
            setPadding(dp(28), dp(28), dp(28), dp(16))
            setOnApplyWindowInsetsListener { v, i ->
                @Suppress("DEPRECATION")
                v.setPadding(dp(28), i.systemWindowInsetTop + dp(28), dp(28), i.systemWindowInsetBottom + dp(16))
                i
            }
        }

        title = TextView(this).apply {
            textSize = 40f
            setTextColor(Pal.TXT)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setPadding(0, dp(14), 0, 0)
        }
        sub = TextView(this).apply { textSize = 16f; setPadding(0, dp(4), 0, dp(20)) }
        timeline = TimelineView(this)
        link = TextView(this).apply {
            textSize = 13f
            setPadding(0, dp(8), 0, dp(24))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }

        val list = ListView(this).apply {
            divider = null
            setSelector(android.R.color.transparent)
            cacheColorHint = Color.TRANSPARENT
            isVerticalScrollBarEnabled = false
            overScrollMode = View.OVER_SCROLL_NEVER
        }
        val adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val on = apps[i].first in chosen
                return ((v as? TextView) ?: TextView(this@MainActivity)).apply {
                    textSize = 17f
                    setPadding(0, dp(13), 0, dp(13))
                    text = (if (on) "●   " else "○   ") + apps[i].second
                    setTextColor(if (on) Pal.WORK else Pal.DIM)
                }
            }
        }
        list.adapter = adapter
        list.setOnItemClickListener { _, _, pos, _ ->
            val pkg = apps[pos].first
            if (!chosen.add(pkg)) chosen.remove(pkg)
            Prefs.save(this, chosen)
            adapter.notifyDataSetChanged()
        }

        root.addView(label("FOCUS  GUARD"))
        root.addView(title)
        root.addView(sub)
        root.addView(timeline)
        root.addView(link)
        root.addView(label("GAME YANG DIKUNCI"))
        root.addView(list, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    override fun onResume() {
        super.onResume()
        h.post(refresh)
    }

    override fun onPause() {
        h.removeCallbacks(refresh)
        super.onPause()
    }

    private fun render() {
        val now = Schedule.nowSec()
        val s = Schedule.status(now)
        val rem = Schedule.remaining(s.untilSec, now)

        title.text = s.label
        sub.text = if (s.open) "Game terbuka  ·  terkunci dalam ${dur(rem)}"
        else "Game terkunci  ·  buka dalam ${dur(rem)}"
        sub.setTextColor(if (s.open) Pal.REST else Pal.WORK)

        timeline.nowSec = now
        timeline.invalidate()

        val on = Settings.Secure.getString(contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES)
            ?.contains(packageName) == true
        link.text = if (on) "●  Penjaga aktif" else "○  Penjaga belum aktif  ·  ketuk untuk mengaktifkan"
        link.setTextColor(if (on) Pal.REST else Pal.WARN)
    }

    private fun dur(sec: Int): String {
        val total = (sec + 59) / 60
        val hh = total / 60
        val mm = total % 60
        return if (hh > 0) "${hh}j ${mm}m" else "${mm}m"
    }
}
