package com.shim.guard

import android.accessibilityservice.AccessibilityService
import android.animation.ValueAnimator
import android.graphics.ImageDecoder
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.AnimatedImageDrawable
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import java.io.File

/**
 * Scene: jendela melayang (animasi + musik) -> memudar -> onDone (notifikasi + suara).
 * Memakai jendela overlay milik layanan aksesibilitas, jadi tidak butuh izin tambahan.
 * Gambar di-decode dan musik disiapkan di latar, jadi layar tidak tersendat dan musik cepat mulai.
 */
class Scene(private val svc: AccessibilityService) {

    private val wm = svc.getSystemService(WindowManager::class.java)
    private val h = Handler(Looper.getMainLooper())
    private var root: View? = null
    private var image: ImageView? = null
    private var player: MediaPlayer? = null
    private var volAnim: ValueAnimator? = null
    private var done: (() -> Unit)? = null
    private var token = 0
    private var fadeAt = FADE_AT
    private var endAt = END_AT

    private val fadeRun = Runnable { fade() }
    private val endRun = Runnable { close(true) }

    fun play(
        kind: Schedule.Kind, title: String, text: String,
        fadeAt: Long = FADE_AT, endAt: Long = END_AT,
        withMusic: Boolean = true, always: Boolean = false,
        onDone: () -> Unit
    ) {
        close(true)   // scene sebelumnya (kalau ada) selesai dulu, notifikasinya tetap terkirim
        val img = Assets.file(svc, "img_${kind.name}")
        val bgm = if (withMusic) Assets.file(svc, "bgm") else null
        if (!always && img == null && bgm == null) { onDone(); return }
        done = onDone
        this.fadeAt = fadeAt
        this.endAt = endAt
        val my = ++token

        startMusic(bgm)   // disiapkan di latar, mulai begitu siap

        if (img == null) {
            show(kind, title, text, null)
            return
        }
        Thread {
            val dr = loadImage(img)
            h.post {
                if (my == token) show(kind, title, text, dr)
                else (dr as? AnimatedImageDrawable)?.stop()
            }
        }.start()
    }

    private fun show(kind: Schedule.Kind, title: String, text: String, dr: Drawable?) {
        val accent = when (kind) {
            Schedule.Kind.REST, Schedule.Kind.TEMPT -> Pal.REST
            Schedule.Kind.WARN -> Pal.WARN
            else -> Pal.WORK
        }
        val d = svc.resources.displayMetrics.density
        fun dp(x: Int) = (x * d).toInt()

        val card = LinearLayout(svc).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(18), dp(18), dp(18), dp(16))
            background = GradientDrawable().apply {
                setColor(0xF2101010.toInt())
                cornerRadius = dp(24).toFloat()
                setStroke(dp(2), accent)
            }
            alpha = 0f
            setOnClickListener { close(true) }   // ketuk untuk menutup lebih cepat
        }

        if (dr != null) {
            val iv = ImageView(svc).apply {
                scaleType = ImageView.ScaleType.FIT_CENTER
                setImageDrawable(dr)
            }
            if (dr is AnimatedImageDrawable) {
                dr.repeatCount = AnimatedImageDrawable.REPEAT_INFINITE
                dr.start()
            }
            image = iv
            card.addView(iv, LinearLayout.LayoutParams(dp(260), dp(260)))
        }

        card.addView(TextView(svc).apply {
            this.text = title
            textSize = 20f
            setTextColor(accent)
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(4))
        })
        card.addView(TextView(svc).apply {
            this.text = text
            textSize = 14f
            setTextColor(Pal.TXT)
            gravity = Gravity.CENTER
        })

        val lp = WindowManager.LayoutParams(
            dp(310), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.CENTER }

        try {
            wm.addView(card, lp)
        } catch (e: Exception) {
            close(true)
            return
        }
        root = card
        card.animate().alpha(1f).setDuration(350).start()

        h.postDelayed(fadeRun, fadeAt)   // mulai memudar
        h.postDelayed(endRun, endAt)     // selesai -> notifikasi + suara
    }

    private fun startMusic(f: File?) {
        if (f == null) return
        try {
            val p = MediaPlayer()
            player = p
            p.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            p.setDataSource(f.absolutePath)
            p.isLooping = true
            p.setOnPreparedListener {
                if (player === it) {
                    it.setVolume(0.8f, 0.8f)
                    it.start()
                }
            }
            p.setOnErrorListener { mp, _, _ ->
                if (player === mp) player = null
                mp.release()
                true
            }
            p.prepareAsync()
        } catch (_: Exception) {
            player = null
        }
    }

    private fun fade() {
        root?.animate()?.alpha(0f)?.setDuration(1500)?.start()
        volAnim = ValueAnimator.ofFloat(0.8f, 0f).apply {
            duration = 1500
            addUpdateListener { a ->
                val v = a.animatedValue as Float
                try { player?.setVolume(v, v) } catch (_: Exception) { }
            }
            start()
        }
    }

    fun stop() = close(false)

    private fun close(fire: Boolean) {
        token++   // membatalkan decode gambar yang masih berjalan
        h.removeCallbacks(fadeRun)
        h.removeCallbacks(endRun)
        volAnim?.cancel(); volAnim = null
        (image?.drawable as? AnimatedImageDrawable)?.stop()
        image = null
        try { player?.stop() } catch (_: Exception) { }
        try { player?.release() } catch (_: Exception) { }
        player = null
        root?.let { try { wm.removeView(it) } catch (_: Exception) { } }
        root = null
        val cb = done
        done = null
        if (fire) cb?.invoke()
    }

    /** Dibatasi sekitar 600 px supaya hemat memori dan baterai. Dipanggil di thread latar. */
    private fun loadImage(f: File): Drawable? = try {
        ImageDecoder.decodeDrawable(ImageDecoder.createSource(f)) { dec, info, _ ->
            dec.setTargetSampleSize(maxOf(1, info.size.width / 600))
        }
    } catch (_: Exception) {
        null
    }

    companion object {
        /** Mulai memudar dan selesai, dalam milidetik sejak scene tampil. Ubah sesuka hati. */
        const val FADE_AT = 7500L
        const val END_AT = 9000L
    }
}
