package com.shim.guard

import android.content.Context
import java.time.LocalTime
import java.time.ZoneId
import java.time.ZonedDateTime

/** Warna: latar hitam murni (hemat daya di layar OLED) + tiga aksen saja. */
object Pal {
    val BG = 0xFF000000.toInt()
    val TXT = 0xFFEDEDED.toInt()
    val DIM = 0xFF6B6B6B.toInt()
    val TRACK = 0xFF222222.toInt()
    val REST = 0xFF7CF2C8.toInt()   // mint  = game terbuka
    val WORK = 0xFFFF6B6B.toInt()   // koral = game terkunci
    val WARN = 0xFFFFC857.toInt()   // kuning = peringatan
}

/** Semua aturan jadwal ada di sini. Ubah angkanya kalau jadwal berubah. */
object Schedule {
    private fun t(h: Int, m: Int, s: Int = 0) = h * 3600 + m * 60 + s
    const val DAY = 86400
    private const val PRE_LOCK = 300            // peringatan 5 menit sebelum terkunci

    class Window(val start: Int, val end: Int)  // [start, end) dalam detik sejak tengah malam

    /** Jendela game TERBUKA. Di luar jendela ini semuanya TERKUNCI. */
    val windows = listOf(
        Window(t(6, 0), t(7, 31)),     // pagi : 06:00 - 07:30  <- ubah sesukamu
        Window(t(11, 0), t(12, 11)),   // siang: 11:00 - 12:10
        Window(t(16, 1), t(19, 31))    // sore : 16:01 - 19:30
    )

    val WARN_AT = t(20, 9, 30)
    val SHUTDOWN_AT = t(20, 10)
    val NIGHT_END = t(5, 0)            // HP dijaga mati/terkunci sampai jam ini

    enum class Kind { REST, SOON, WORK, WARN, SHUT }

    /** until = jam (detik) yang dihitung mundur di notifikasi. */
    class Event(
        val id: String, val at: Int, val kind: Kind,
        val title: String, val text: String, val say: String, val until: Int
    )

    fun fmt(sec: Int) = "%02d:%02d".format(sec / 3600 % 24, sec / 60 % 60)

    private fun spoken(sec: Int): String {
        val h = sec / 3600 % 24
        val m = sec / 60 % 60
        return if (m == 0) "$h" else "$h lewat $m menit"
    }

    val events: List<Event> = buildList {
        windows.forEachIndexed { i, w ->
            val nextStart = windows.getOrNull(i + 1)?.start
            add(Event("rest$i", w.start, Kind.REST, "Waktu istirahat",
                "Game terbuka sampai ${fmt(w.end - 60)}.",
                "Waktu istirahat, tuan. Game terbuka sampai pukul ${spoken(w.end - 60)}.", w.end))
            add(Event("soon$i", w.end - PRE_LOCK, Kind.SOON, "5 menit lagi",
                "Game terkunci pukul ${fmt(w.end)}. Rapikan dulu progresmu.",
                "Lima menit lagi game terkunci, tuan.", w.end))
            if (nextStart != null) {
                add(Event("work$i", w.end, Kind.WORK, "Waktu kerja",
                    "Game terkunci sampai ${fmt(nextStart - 60)}.",
                    "Waktu kerja, tuan. Game terkunci.", nextStart))
            } else {
                add(Event("work$i", w.end, Kind.WORK, "Waktu kerja/belajar",
                    "Game terkunci. Fokus sampai malam.",
                    "Waktu kerja dan belajar, tuan. Game terkunci.", SHUTDOWN_AT))
            }
        }
        add(Event("warn", WARN_AT, Kind.WARN, "PERINGATAN",
            "hp akan dimatikan dalam 30s, tuan.",
            "HP akan dimatikan dalam tiga puluh detik, tuan.", SHUTDOWN_AT))
        add(Event("shut", SHUTDOWN_AT, Kind.SHUT, "", "", "", SHUTDOWN_AT))
    }

    private val cheerWork = listOf(
        "Fokus sebentar, hadiahnya menunggu.",
        "Satu langkah kecil hari ini sudah cukup berarti.",
        "Kamu lebih kuat dari rasa malas."
    )
    private val cheerRest = listOf(
        "Kamu sudah bekerja keras. Nikmati waktumu.",
        "Istirahat itu bagian dari kemajuan.",
        "Main dengan tenang, nanti kita fokus lagi."
    )

    fun cheer(k: Kind) = when (k) {
        Kind.REST -> cheerRest.random()
        Kind.WORK -> cheerWork.random()
        Kind.SOON -> "Selesaikan dulu yang sedang berjalan."
        Kind.WARN -> "Selamat beristirahat, tuan."
        Kind.SHUT -> ""
    }

    fun isOpen(sec: Int) = windows.any { sec >= it.start && sec < it.end }
    fun isNight(sec: Int) = sec >= SHUTDOWN_AT || sec < NIGHT_END
    fun nowSec() = LocalTime.now().toSecondOfDay()

    /** Detik dari [now] sampai [until] (membungkus lewat tengah malam). */
    fun remaining(until: Int, now: Int) = ((until - now) % DAY + DAY) % DAY

    class Status(val label: String, val open: Boolean, val untilSec: Int)

    fun status(now: Int): Status {
        windows.firstOrNull { now >= it.start && now < it.end }?.let {
            return Status("Waktu istirahat", true, it.end)
        }
        val next = windows.firstOrNull { it.start > now }?.start ?: windows.first().start
        val label = when {
            isNight(now) -> "Malam"
            else -> if (now >= windows.last().end) "Waktu kerja/belajar" else "Waktu kerja"
        }
        return Status(label, false, next)
    }

    /** Waktu alarm berikutnya (epoch ms) = batas jadwal terdekat. */
    fun nextTriggerMillis(): Long {
        val zone = ZoneId.systemDefault()
        val now = ZonedDateTime.now(zone)
        val sod = now.toLocalTime().toSecondOfDay()
        val ats = events.map { it.at }.distinct().sorted()
        val base = now.toLocalDate().atStartOfDay(zone)
        val next = ats.firstOrNull { it > sod }
        val target = if (next != null) base.plusSeconds(next.toLong())
        else base.plusDays(1).plusSeconds(ats.first().toLong())
        return target.toInstant().toEpochMilli()
    }
}

object Prefs {
    private const val FILE = "guard"
    private const val KEY = "blocked"

    fun blocked(c: Context): Set<String> =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).getStringSet(KEY, emptySet()) ?: emptySet()

    fun save(c: Context, pkgs: Set<String>) =
        c.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putStringSet(KEY, HashSet(pkgs)).apply()
}
