package com.shim.guard

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.io.File
import java.util.Locale

/**
 * Suara yang DISIAPKAN LEBIH DULU (prepare) lalu dimainkan (play) tepat waktunya.
 * File suara: dimuat di latar (prepareAsync), tidak memblokir layar.
 * Tanpa file: mesin suara bawaan HP (TTS) dinyalakan lebih awal, karena start-nya lambat 1-2 detik.
 */
class VoiceClip(private val ctx: Context?, private val file: File?, private val line: String) {

    private val h = Handler(Looper.getMainLooper())
    private var mp: MediaPlayer? = null
    private var tts: TextToSpeech? = null
    private var ready = false
    private var want = false
    private var released = false

    fun prepare() {
        if (file != null) {
            try {
                val p = MediaPlayer()
                mp = p
                p.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_UNKNOWN)
                        .build()
                )
                p.setDataSource(file.absolutePath)
                p.setOnPreparedListener {
                    ready = true
                    if (want && !released) it.start()
                }
                p.setOnCompletionListener { release() }
                p.setOnErrorListener { _, _, _ -> release(); true }
                p.prepareAsync()
            } catch (_: Exception) {
                release()
            }
        } else if (ctx != null && line.isNotBlank()) {
            tts = TextToSpeech(ctx) { status ->
                val t = tts
                if (t == null || released) { t?.shutdown(); return@TextToSpeech }
                if (status != TextToSpeech.SUCCESS) { release(); return@TextToSpeech }
                val id = Locale.forLanguageTag("id-ID")
                if (t.isLanguageAvailable(id) >= TextToSpeech.LANG_AVAILABLE) t.language = id
                t.setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                        .build()
                )
                t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                    override fun onStart(utteranceId: String?) {}
                    override fun onDone(utteranceId: String?) { h.post { release() } }
                    @Deprecated("Deprecated in Java")
                    override fun onError(utteranceId: String?) { h.post { release() } }
                })
                ready = true
                if (want) speak()
            }
        }
        h.postDelayed({ release() }, 60_000)   // pengaman supaya tidak pernah menggantung
    }

    /** Mainkan sekarang. Kalau belum siap, otomatis dimulai begitu siap. */
    fun play() {
        want = true
        if (!ready || released) return
        if (mp != null) mp?.start() else speak()
    }

    private fun speak() {
        tts?.speak(line, TextToSpeech.QUEUE_FLUSH, null, "guard")
    }

    fun release() {
        if (released) return
        released = true
        h.removeCallbacksAndMessages(null)
        try { mp?.release() } catch (_: Exception) { }
        mp = null
        try { tts?.shutdown() } catch (_: Exception) { }
        tts = null
    }
}

object Sfx {
    /** Suara pendek sekali putar, dimuat di latar. */
    fun play(file: File) {
        VoiceClip(null, file, "").apply {
            prepare()
            play()
        }
    }
}
