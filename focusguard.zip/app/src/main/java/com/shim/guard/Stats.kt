package com.shim.guard

import android.content.Context
import java.time.LocalDate

/** Penghitung godaan: berapa kali kamu mencoba membuka game saat terkunci. Hanya tersimpan di HP-mu. */
object Stats {
    private fun p(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)
    private fun key(d: LocalDate) = "t_$d"

    /** Tambah satu percobaan untuk hari ini, mengembalikan total hari ini. */
    fun add(c: Context): Int {
        val prefs = p(c)
        val k = key(LocalDate.now())
        val n = prefs.getInt(k, 0) + 1
        val e = prefs.edit().putInt(k, n)
        val limit = LocalDate.now().minusDays(30)   // pangkas data yang lebih dari 30 hari
        for (name in prefs.all.keys) {
            if (!name.startsWith("t_")) continue
            try {
                if (LocalDate.parse(name.substring(2)).isBefore(limit)) e.remove(name)
            } catch (_: Exception) { }
        }
        e.apply()
        return n
    }

    /** 7 hari terakhir, dari yang terlama sampai hari ini. */
    fun week(c: Context): List<Int> {
        val prefs = p(c)
        val today = LocalDate.now()
        return (6 downTo 0).map { prefs.getInt(key(today.minusDays(it.toLong())), 0) }
    }

    /** Grafik mini dengan karakter blok, misalnya ▁▂▁▄▃▁▂ */
    fun spark(v: List<Int>): String {
        val blocks = "▁▂▃▄▅▆▇█"
        val m = v.max()
        return v.joinToString("") { if (m == 0) blocks[0].toString() else blocks[it * 7 / m].toString() }
    }
}

/** Daftar 1-3 tugas fokus. Tampil di layar utama, scene waktu kerja, dan notifikasi waktu kerja. */
object Tasks {
    const val N = 3

    private fun p(c: Context) = c.getSharedPreferences("tasks", Context.MODE_PRIVATE)

    fun get(c: Context, i: Int): String = p(c).getString("t$i", "") ?: ""

    fun set(c: Context, i: Int, text: String) {
        p(c).edit().putString("t$i", text).apply()
    }

    /** Tanda selesai berlaku untuk hari ini saja, besok kembali kosong. */
    fun isDone(c: Context, i: Int): Boolean {
        val s = p(c)
        return s.getString("dd", "") == LocalDate.now().toString() && s.getBoolean("d$i", false)
    }

    fun toggle(c: Context, i: Int) {
        val s = p(c)
        val today = LocalDate.now().toString()
        val nowDone = isDone(c, i)
        val e = s.edit()
        if (s.getString("dd", "") != today) {
            for (j in 0 until N) e.putBoolean("d$j", false)
            e.putString("dd", today)
        }
        e.putBoolean("d$i", !nowDone).apply()
    }

    private fun filled(c: Context) = (0 until N).filter { get(c, it).isNotBlank() }

    fun summary(c: Context): String {
        val all = filled(c)
        if (all.isEmpty()) return ""
        val open = all.filter { !isDone(c, it) }
        return if (open.isEmpty()) "Semua tugas selesai. Keren!"
        else "Fokus hari ini:\n" + open.joinToString("\n") { "• " + get(c, it).trim() }
    }

    /** Untuk layar utama: ○ belum, ● selesai. */
    fun board(c: Context): String =
        filled(c).joinToString("\n") { (if (isDone(c, it)) "●  " else "○  ") + get(c, it).trim() }
}
