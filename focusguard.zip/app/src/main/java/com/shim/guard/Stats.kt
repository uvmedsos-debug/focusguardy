package com.shim.guard

import android.content.Context
import java.time.LocalDate
import java.time.temporal.ChronoUnit

/** Penghitung godaan: berapa kali kamu mencoba membuka game saat terkunci. Hanya tersimpan di HP-mu. */
object Stats {
    private fun p(c: Context) = c.getSharedPreferences("stats", Context.MODE_PRIVATE)
    private fun key(d: LocalDate) = "t_$d"

    /** Tambah satu percobaan untuk hari ini, mengembalikan total hari ini. */
    fun add(c: Context): Int {
        val prefs = p(c)
        val k = key(LocalDate.now())
        val n = prefs.getInt(k, 0) + 1
        val e = prefs.edit().putInt(k, n)
        val limit = LocalDate.now().minusDays(30)   // pangkas data yang lebih dari 30 hari
        for (name in prefs.all.keys) {
            if (!(name.startsWith("t_") || name.startsWith("w_"))) continue
            try {
                if (LocalDate.parse(name.substring(2)).isBefore(limit)) e.remove(name)
            } catch (_: Exception) { }
        }
        e.apply()
        return n
    }

    /** Satu kali bertahan 10 menit setelah tergoda. Mengembalikan total sepanjang waktu. */
    fun addWin(c: Context): Int {
        val prefs = p(c)
        val k = "w_" + LocalDate.now()
        val total = prefs.getInt("wins", 0) + 1
        prefs.edit().putInt("wins", total).putInt(k, prefs.getInt(k, 0) + 1).apply()
        return total
    }

    fun wins(c: Context) = p(c).getInt("wins", 0)
    fun winsToday(c: Context) = p(c).getInt("w_" + LocalDate.now(), 0)
    fun days(c: Context) = p(c).getInt("days", 0)

    /**
     * Dicatat sekali per hari saat penjaga berjalan. Mengembalikan jumlah hari yang terlewat
     * sejak terakhir aktif (0 kalau berurutan). Kemajuan tidak pernah di-reset.
     */
    fun markActive(c: Context): Long {
        val prefs = p(c)
        val today = LocalDate.now()
        val last = prefs.getString("last", null)?.let {
            try { LocalDate.parse(it) } catch (_: Exception) { null }
        }
        if (last == today) return 0
        val gap = if (last == null) 0L else ChronoUnit.DAYS.between(last, today) - 1
        prefs.edit().putString("last", today.toString()).putInt("days", prefs.getInt("days", 0) + 1).apply()
        return gap.coerceAtLeast(0)
    }

    /** 7 hari terakhir, dari yang terlama sampai hari ini. */
    fun week(c: Context): List<Int> {
        val prefs = p(c)
        val today = LocalDate.now()
        return (6 downTo 0).map { prefs.getInt(key(today.minusDays(it.toLong())), 0) }
    }

    /** Grafik mini dengan karakter blok, misalnya ▁▂▁▄▃▁▂ */
    fun spark(v: List<Int>): String {
        val blocks = "▁▂▃▄▅▆▇█"
        val m = v.max()
        return v.joinToString("") { if (m == 0) blocks[0].toString() else blocks[it * 7 / m].toString() }
    }
}

/** Daftar 1-3 tugas fokus. Tampil di layar utama, scene waktu kerja, dan notifikasi waktu kerja. */
object Tasks {
    const val N = 3

    private fun p(c: Context) = c.getSharedPreferences("tasks", Context.MODE_PRIVATE)

    fun get(c: Context, i: Int): String = p(c).getString("t$i", "") ?: ""

    fun set(c: Context, i: Int, text: String) {
        p(c).edit().putString("t$i", text).apply()
    }

    /** Tanda selesai berlaku untuk hari ini saja, besok kembali kosong. */
    fun isDone(c: Context, i: Int): Boolean {
        val s = p(c)
        return s.getString("dd", "") == LocalDate.now().toString() && s.getBoolean("d$i", false)
    }

    fun toggle(c: Context, i: Int) {
        val s = p(c)
        val today = LocalDate.now().toString()
        val nowDone = isDone(c, i)
        val e = s.edit()
        if (s.getString("dd", "") != today) {
            for (j in 0 until N) e.putBoolean("d$j", false)
            e.putString("dd", today)
        }
        e.putBoolean("d$i", !nowDone).apply()
    }

    private fun filled(c: Context) = (0 until N).filter { get(c, it).isNotBlank() }

    fun summary(c: Context): String {
        val all = filled(c)
        if (all.isEmpty()) return ""
        val open = all.filter { !isDone(c, it) }
        return if (open.isEmpty()) "Semua tugas selesai. Keren!"
        else "Fokus hari ini:\n" + open.joinToString("\n") { "• " + get(c, it).trim() }
    }

    /** Untuk layar utama: ○ belum, ● selesai. */
    fun board(c: Context): String =
        filled(c).joinToString("\n") { (if (isDone(c, it)) "●  " else "○  ") + get(c, it).trim() }
}
