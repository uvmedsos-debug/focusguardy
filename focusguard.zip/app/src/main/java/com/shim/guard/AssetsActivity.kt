package com.shim.guard

import android.app.Activity
import android.content.Intent
import android.graphics.Typeface
import android.os.Bundle
import android.provider.Settings
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

/** Layar untuk memilih animasi dan suara sendiri, serta mencoba scene-nya. */
class AssetsActivity : Activity() {

    private var pending: Assets.Slot? = null
    private val status = HashMap<String, TextView>()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    private fun label(text: String) = TextView(this).apply {
        this.text = text
        textSize = 11f
        letterSpacing = 0.25f
        setTextColor(Pal.DIM)
        typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        setPadding(0, dp(22), 0, dp(6))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Pal.BG
        window.navigationBarColor = Pal.BG

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(28), dp(28), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Pal.BG)
            isVerticalScrollBarEnabled = false
            addView(col)
            setOnApplyWindowInsetsListener { _, i ->
                @Suppress("DEPRECATION")
                col.setPadding(dp(28), i.systemWindowInsetTop + dp(28), dp(28), i.systemWindowInsetBottom + dp(32))
                i
            }
        }

        col.addView(TextView(this).apply {
            text = "SUARA  &  ANIMASI"
            textSize = 11f
            letterSpacing = 0.25f
            setTextColor(Pal.DIM)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        col.addView(TextView(this).apply {
            text = "Ketuk untuk memilih file, tahan lama untuk menghapus.\n" +
                "Animasi: GIF atau WebP animasi. Suara: MP3, OGG, atau M4A.\n" +
                "Kalau suara dikosongkan, dipakai suara bawaan HP."
            textSize = 13f
            setTextColor(Pal.DIM)
            setPadding(0, dp(10), 0, 0)
        })

        for (s in Assets.slots) {
            when (s.key) {
                "bgm" -> col.addView(label("MUSIK LATAR"))
                "img_REST" -> col.addView(label("ANIMASI"))
                "voice_REST" -> col.addView(label("SUARA"))
            }
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener { pick(s) }
                setOnLongClickListener {
                    Assets.remove(this@AssetsActivity, s.key)
                    refresh()
                    Toast.makeText(this@AssetsActivity, "Dihapus.", Toast.LENGTH_SHORT).show()
                    true
                }
            }
            row.addView(TextView(this).apply {
                text = s.label
                textSize = 17f
                setTextColor(Pal.TXT)
            })
            val st = TextView(this).apply { textSize = 12f }
            status[s.key] = st
            row.addView(st)
            col.addView(row)
        }

        col.addView(label("COBA SCENE"))
        val tests = listOf(
            Triple("REST", "Istirahat", Pal.REST),
            Triple("WORK", "Kerja", Pal.WORK),
            Triple("SOON", "5 menit lagi", Pal.WORK),
            Triple("WARN", "Peringatan malam", Pal.WARN)
        )
        for ((k, n, color) in tests) {
            col.addView(TextView(this).apply {
                text = "▶   $n"
                textSize = 17f
                setTextColor(color)
                setPadding(0, dp(10), 0, dp(10))
                setOnClickListener {
                    val on = Settings.Secure.getString(
                        contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
                    )?.contains(packageName) == true
                    if (!on) {
                        Toast.makeText(this@AssetsActivity, "Aktifkan penjaga dulu.", Toast.LENGTH_SHORT).show()
                    } else {
                        sendBroadcast(
                            Intent(GuardService.ACT_PREVIEW).setPackage(packageName).putExtra("kind", k)
                        )
                    }
                }
            })
        }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        for (s in Assets.slots) {
            val f = Assets.file(this, s.key)
            status[s.key]?.apply {
                text = if (f != null) "●  terpasang  ·  ${f.length() / 1024} KB" else "○  belum ada"
                setTextColor(if (f != null) Pal.REST else Pal.DIM)
            }
        }
    }

    private fun pick(s: Assets.Slot) {
        pending = s
        startActivityForResult(
            Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType(s.mime),
            1
        )
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        val s = pending ?: return
        pending = null
        val uri = data?.data ?: return
        if (resultCode != RESULT_OK) return
        Thread {
            val err = Assets.import(this, uri, s)
            runOnUiThread {
                Toast.makeText(this, err ?: "Tersimpan.", Toast.LENGTH_SHORT).show()
                refresh()
            }
        }.start()
    }
}
