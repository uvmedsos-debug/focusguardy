package com.shim.guard

import android.app.Activity
import android.app.ActivityManager
import android.app.AlarmManager
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File

/**
 * Tombol darurat: menghapus SEMUA data Focus Guard dan mematikan penjagaan.
 * Sengaja ada jeda tunggu: ketik kata kunci, lalu hitung mundur yang batal kalau kamu pergi dari layar ini.
 * Itu melindungi dari keputusan impulsif saat sedang tergoda, tapi tetap tersedia kalau HP benar-benar bermasalah.
 */
class EmergencyActivity : Activity() {

    private val h = Handler(Looper.getMainLooper())
    private var left = 0
    private var running = false
    private lateinit var input: EditText
    private lateinit var start: TextView
    private lateinit var count: TextView
    private lateinit var cancel: TextView

    private val tick = object : Runnable {
        override fun run() {
            left--
            if (left <= 0) {
                running = false
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                count.text = "Menghapus…"
                Wipe.run(this@EmergencyActivity)
            } else {
                count.text = label(left)
                h.postDelayed(this, 1000)
            }
        }
    }

    private fun dp(x: Int) = Ui.dp(this, x)
    private fun label(s: Int) = "Menghapus dalam %d:%02d".format(s / 60, s % 60)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.lowPower(this, 30f)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(28), dp(28), dp(32))
        }
        val scroll = ScrollView(this).apply {
            isVerticalScrollBarEnabled = false
            addView(col)
            setOnApplyWindowInsetsListener { _, i ->
                @Suppress("DEPRECATION")
                col.setPadding(dp(28), i.systemWindowInsetTop + dp(28), dp(28), i.systemWindowInsetBottom + dp(32))
                i
            }
        }

        col.addView(Ui.caps(this, "DARURAT").apply { setTextColor(Pal.WARN) })
        col.addView(TextView(this).apply {
            text = "Tombol ini menghapus SEMUA data Focus Guard di HP ini: pengaturan, daftar game, " +
                "tugas, statistik, serta file suara dan animasi. Ia juga mematikan penjagaan, " +
                "membatalkan alarm dan notifikasi, lalu membuka layar untuk mencopot aplikasinya.\n\n" +
                "Pakai hanya kalau HP benar-benar bermasalah. Setelah selesai, ini tidak bisa dibatalkan."
            textSize = 14f
            setTextColor(Pal.TXT)
            setLineSpacing(0f, 1.2f)
            setPadding(0, dp(14), 0, dp(14))
        })
        col.addView(TextView(this).apply {
            text = "Supaya tidak terpencet saat sedang tergoda: ketik DARURAT, lalu tunggu " +
                "${COOLDOWN / 60} menit tanpa meninggalkan layar ini."
            textSize = 13f
            setTextColor(Pal.DIM)
            setPadding(0, 0, 0, dp(14))
        })

        input = EditText(this).apply {
            hint = "ketik: DARURAT"
            setHintTextColor(Pal.DIM)
            setTextColor(Pal.TXT)
            textSize = 18f
            background = null
            setSingleLine()
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_CHARACTERS or
                InputType.TYPE_TEXT_FLAG_NO_SUGGESTIONS
        }
        start = Ui.caps(this, "MULAI", 14f).apply {
            setTextColor(Pal.WARN)
            setPadding(0, dp(16), 0, dp(16))
            isEnabled = false
            alpha = 0.3f
            setOnClickListener { begin() }
        }
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val ok = s?.toString()?.trim()?.uppercase() == "DARURAT"
                start.isEnabled = ok
                start.alpha = if (ok) 1f else 0.3f
            }
        })
        count = TextView(this).apply {
            textSize = 20f
            setTextColor(Pal.WARN)
            visibility = View.GONE
            setPadding(0, dp(16), 0, dp(8))
        }
        cancel = Ui.caps(this, "BATALKAN", 14f).apply {
            setTextColor(Pal.TXT)
            visibility = View.GONE
            setPadding(0, dp(12), 0, dp(12))
            setOnClickListener { stopCountdown("Dibatalkan.") }
        }

        col.addView(input)
        col.addView(start)
        col.addView(count)
        col.addView(cancel)
        col.addView(TextView(this).apply {
            text = "Kalau HP terkunci di malam hari (20:10-05:00) dan kamu tidak bisa membuka aplikasi ini: " +
                "nyalakan HP dalam Safe Mode (tahan ikon Power off di menu power), lalu copot " +
                "Focus Guard lewat Settings."
            textSize = 12f
            setTextColor(Pal.DIM)
            setLineSpacing(0f, 1.2f)
            setPadding(0, dp(36), 0, 0)
        })

        setContentView(scroll)
    }

    private fun begin() {
        running = true
        left = COOLDOWN
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)   // hanya selama hitung mundur
        input.isEnabled = false
        start.visibility = View.GONE
        count.visibility = View.VISIBLE
        cancel.visibility = View.VISIBLE
        count.text = label(left)
        h.postDelayed(tick, 1000)
    }

    private fun stopCountdown(message: String?) {
        h.removeCallbacks(tick)
        running = false
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        input.isEnabled = true
        input.setText("")
        start.visibility = View.VISIBLE
        count.visibility = View.GONE
        cancel.visibility = View.GONE
        if (message != null) Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onPause() {
        if (running) stopCountdown("Dibatalkan karena kamu meninggalkan layar.")
        super.onPause()
    }

    companion object {
        /** Jeda tunggu sebelum penghapusan, dalam detik. Naikkan kalau mau lebih ketat. */
        const val COOLDOWN = 120
    }
}

/** Menghapus semua jejak Focus Guard. */
object Wipe {
    fun run(a: Activity) {
        // 1. Hentikan layanan penjaga (dan matikan dirinya sendiri)
        a.sendBroadcast(Intent(GuardService.ACT_WIPE).setPackage(a.packageName))

        // 2. Alarm dan notifikasi, jaga-jaga kalau layanan sedang tidak berjalan
        val pi = PendingIntent.getBroadcast(
            a, 0, Intent(GuardService.ACT_TICK).setPackage(a.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        a.getSystemService(AlarmManager::class.java).cancel(pi)
        val piWin = PendingIntent.getBroadcast(
            a, 1, Intent(GuardService.ACT_WIN).setPackage(a.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        a.getSystemService(AlarmManager::class.java).cancel(piWin)
        a.getSystemService(NotificationManager::class.java).apply {
            cancelAll()
            for (ch in notificationChannels) deleteNotificationChannel(ch.id)
        }

        // 3. Berkas unggahan, cache, dan semua pengaturan
        File(a.filesDir, "assets").deleteRecursively()
        a.cacheDir.deleteRecursively()
        for (name in listOf(Prefs.FILE, "stats", "tasks")) a.deleteSharedPreferences(name)

        // 4. Buka layar pencopotan aplikasi
        try {
            a.startActivity(Intent(Intent.ACTION_DELETE, Uri.parse("package:" + a.packageName)))
        } catch (_: Exception) { }

        // 5. Hapus sisa data aplikasi (juga menghentikan paksa proses ini)
        Handler(Looper.getMainLooper()).postDelayed({
            try {
                a.getSystemService(ActivityManager::class.java).clearApplicationUserData()
            } catch (_: Exception) {
                a.finishAffinity()
            }
        }, 2500)
    }
}
