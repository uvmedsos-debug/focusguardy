package com.shim.guard

import android.app.Activity
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** Tulis 1-3 hal yang mau kamu selesaikan. Ketuk bulatannya kalau sudah selesai. */
class TasksActivity : Activity() {

    private val marks = ArrayList<TextView>()

    private fun dp(x: Int) = (x * resources.displayMetrics.density).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Ui.lowPower(this, 30f)

        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(28), dp(28), dp(28), dp(32))
        }
        val scroll = ScrollView(this).apply {
            setBackgroundColor(Pal.BG)
            isVerticalScrollBarEnabled = false
            addView(col)
            setOnApplyWindowInsetsListener { _, i ->
                @Suppress("DEPRECATION")
                col.setPadding(dp(28), i.systemWindowInsetTop + dp(28), dp(28), i.systemWindowInsetBottom + dp(32))
                i
            }
        }

        col.addView(TextView(this).apply {
            text = "FOKUS  HARI  INI"
            textSize = 11f
            letterSpacing = 0.25f
            setTextColor(Pal.DIM)
            typeface = Typeface.create("sans-serif-medium", Typeface.NORMAL)
        })
        col.addView(TextView(this).apply {
            text = "Tulis 1 sampai 3 hal yang mau kamu selesaikan di jam kerja. " +
                "Tugasnya muncul di scene dan notifikasi waktu kerja. " +
                "Ketuk bulatannya kalau sudah selesai."
            textSize = 13f
            setTextColor(Pal.DIM)
            setPadding(0, dp(10), 0, dp(20))
        })

        for (i in 0 until Tasks.N) {
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = Gravity.CENTER_VERTICAL
                setPadding(0, dp(6), 0, dp(6))
            }
            val mark = TextView(this).apply {
                textSize = 22f
                setPadding(0, 0, dp(14), 0)
                setOnClickListener {
                    Tasks.toggle(this@TasksActivity, i)
                    refresh()
                }
            }
            marks.add(mark)
            val edit = EditText(this).apply {
                setText(Tasks.get(this@TasksActivity, i))
                hint = "Tugas ${i + 1}"
                setHintTextColor(Pal.DIM)
                setTextColor(Pal.TXT)
                textSize = 17f
                background = null
                setSingleLine()
                addTextChangedListener(object : TextWatcher {
                    override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
                    override fun afterTextChanged(s: Editable?) {
                        Tasks.set(this@TasksActivity, i, s?.toString() ?: "")
                    }
                })
            }
            row.addView(mark)
            row.addView(edit, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
            col.addView(row)
        }

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        for (i in 0 until Tasks.N) {
            val done = Tasks.isDone(this, i)
            marks[i].text = if (done) "●" else "○"
            marks[i].setTextColor(if (done) Pal.REST else Pal.DIM)
        }
    }
}
