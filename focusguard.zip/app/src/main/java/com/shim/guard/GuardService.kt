package com.shim.guard

import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.time.LocalDate
import java.util.Locale

/**
 * Hemat daya: TIDAK ada polling/timer per detik.
 *  - Alarm sistem membangunkan layanan hanya pada batas jadwal (sekitar 10x sehari).
 *  - Penguncian game digerakkan oleh event pergantian jendela.
 *  - Penjagaan malam digerakkan oleh event layar menyala.
 */
class GuardService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private val fired = HashMap<String, String>()   // id event -> tanggal terakhir dikirim
    private var shutdownDay = ""
    private var powerOffFailed = false
    private var lastToast = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> if (Schedule.isNight(Schedule.nowSec())) nightGuard()
                else -> sync()   // alarm jadwal, atau jam/zona waktu diubah
            }
        }
    }

    override fun onServiceConnected() {
        createChannels()
        val f = IntentFilter().apply {
            addAction(ACT_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        sync()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        if (e.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            e.packageName?.toString()?.let { enforce(it) }
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    // ---------- inti jadwal ----------

    private fun sync() {
        try {
            val now = Schedule.nowSec()
            val today = LocalDate.now().toString()
            for (ev in Schedule.events) {
                if (ev.kind == Schedule.Kind.SHUT) continue
                if (now >= ev.at && now < ev.at + 120 && fired[ev.id] != today) {
                    fired[ev.id] = today
                    notifyEvent(ev)
                    speak(ev)
                }
            }
            if (!Schedule.isOpen(now)) {   // game yang sudah terbuka saat waktu kunci tiba
                rootInActiveWindow?.packageName?.toString()?.let { enforce(it) }
            }
            if (Schedule.isNight(now)) nightGuard()
            postStatus(now)
        } finally {
            scheduleNext()
        }
    }

    private fun scheduleNext() {
        val am = getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(ACT_TICK).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = Schedule.nextTriggerMillis()
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    private fun enforce(pkg: String) {
        if (Schedule.isOpen(Schedule.nowSec())) return
        if (pkg in Prefs.blocked(this)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val t = System.currentTimeMillis()
            if (t - lastToast > 3000) {
                lastToast = t
                Toast.makeText(this, "Terkunci. Fokus dulu, tuan.", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun nightGuard() {
        val today = LocalDate.now().toString()
        if (shutdownDay != today) {
            shutdownDay = today
            Thread {
                try {
                    val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot -p"))
                    if (p.waitFor() != 0) failedPowerOff()
                } catch (_: Exception) {
                    failedPowerOff()
                }
            }.start()
        } else if (powerOffFailed) {
            lockIfOn()
        }
    }

    private fun failedPowerOff() {
        powerOffFailed = true
        main.post { lockIfOn() }
    }

    private fun lockIfOn() {
        if (getSystemService(PowerManager::class.java).isInteractive) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    // ---------- notifikasi ----------

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.deleteNotificationChannel("guard")
        nm.createNotificationChannel(NotificationChannel("rest", "Istirahat", NotificationManager.IMPORTANCE_DEFAULT))
        nm.createNotificationChannel(NotificationChannel("work", "Waktu kerja", NotificationManager.IMPORTANCE_HIGH))
        nm.createNotificationChannel(
            NotificationChannel("warn", "Peringatan", NotificationManager.IMPORTANCE_HIGH).apply {
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel("status", "Status", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            }
        )
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    /** Hitung mundur ditangani sistem (chronometer): tanpa update dari aplikasi. */
    private fun endMillis(until: Int, now: Int) =
        System.currentTimeMillis() + Schedule.remaining(until, now) * 1000L

    private fun notifyEvent(ev: Schedule.Event) {
        val color = when (ev.kind) {
            Schedule.Kind.REST -> Pal.REST
            Schedule.Kind.WARN -> Pal.WARN
            else -> Pal.WORK
        }
        val channel = when (ev.kind) {
            Schedule.Kind.REST -> "rest"
            Schedule.Kind.WARN -> "warn"
            else -> "work"
        }
        val n = Notification.Builder(this, channel)
            .setSmallIcon(R.drawable.ic_guard)
            .setColor(color)
            .setContentTitle(ev.title)
            .setContentText(ev.text)
            .setStyle(Notification.BigTextStyle().bigText(ev.text + "\n" + Schedule.cheer(ev.kind)))
            .setWhen(endMillis(ev.until, Schedule.nowSec()))
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ev.id.hashCode(), n)
    }

    private fun postStatus(now: Int) {
        val s = Schedule.status(now)
        val n = Notification.Builder(this, "status")
            .setSmallIcon(R.drawable.ic_guard)
            .setColor(if (s.open) Pal.REST else Pal.WORK)
            .setContentTitle(s.label)
            .setContentText(if (s.open) "Game terbuka" else "Game terkunci")
            .setWhen(endMillis(s.untilSec, now))
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    // ---------- suara (TTS bawaan Android, offline, tanpa internet) ----------

    /** Hanya bicara kalau layar menyala. Mesin suara dibuat saat perlu, lalu dilepas. */
    private fun speak(ev: Schedule.Event) {
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        val line = ev.say + " " + Schedule.cheer(ev.kind)
        var engine: TextToSpeech? = null
        engine = TextToSpeech(this) { status ->
            val e = engine
            if (e == null) return@TextToSpeech
            if (status != TextToSpeech.SUCCESS) { e.shutdown(); return@TextToSpeech }
            val id = Locale.forLanguageTag("id-ID")
            if (e.isLanguageAvailable(id) >= TextToSpeech.LANG_AVAILABLE) e.language = id
            e.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { e.shutdown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { e.shutdown() }
            })
            e.speak(line, TextToSpeech.QUEUE_FLUSH, null, "guard")
        }
    }

    companion object {
        const val ACT_TICK = "com.shim.guard.TICK"
    }
}
