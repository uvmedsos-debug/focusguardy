package com.shim.guard

import android.accessibilityservice.AccessibilityService
import android.app.AlarmManager
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.AudioAttributes
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.os.PowerManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast
import java.time.LocalDate
import java.util.Locale

/**
 * Hemat daya: TIDAK ada polling/timer per detik.
 *  - Alarm sistem membangunkan layanan hanya pada batas jadwal (sekitar 10x sehari).
 *  - Penguncian game digerakkan oleh event pergantian jendela.
 *  - Penjagaan malam digerakkan oleh event layar menyala.
 */
class GuardService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private val fired = HashMap<String, String>()   // id event -> tanggal terakhir dikirim
    private var shutdownDay = ""
    private var powerOffFailed = false
    private var lastToast = 0L

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            when (i.action) {
                Intent.ACTION_SCREEN_ON -> if (Schedule.isNight(Schedule.nowSec())) nightGuard()
                ACT_PREVIEW -> preview(i.getStringExtra("kind"))
                else -> sync()   // alarm jadwal, atau jam/zona waktu diubah
            }
        }
    }

    override fun onServiceConnected() {
        createChannels()
        val f = IntentFilter().apply {
            addAction(ACT_TICK)
            addAction(Intent.ACTION_TIME_CHANGED)
            addAction(Intent.ACTION_TIMEZONE_CHANGED)
            addAction(Intent.ACTION_SCREEN_ON)
            addAction(ACT_PREVIEW)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED)
        else registerReceiver(receiver, f)
        sync()
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        when (e.eventType) {
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> { enforce(pkg); protectSelf(pkg) }
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> protectSelf(pkg)
        }
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scene.stop()
        try { unregisterReceiver(receiver) } catch (_: Exception) { }
        super.onDestroy()
    }

    // ---------- inti jadwal ----------

    private fun sync() {
        try {
            val now = Schedule.nowSec()
            val today = LocalDate.now().toString()
            for (ev in Schedule.events) {
                if (ev.kind == Schedule.Kind.SHUT) continue
                if (now >= ev.at && now < ev.at + 120 && fired[ev.id] != today) {
                    fired[ev.id] = today
                    deliver(ev)
                }
            }
            if (!Schedule.isOpen(now)) {   // game yang sudah terbuka saat waktu kunci tiba
                kickForeground()
                for (d in longArrayOf(1500, 4000, 8000)) main.postDelayed({ kickForeground() }, d)
            }
            if (Schedule.isNight(now)) nightGuard()
            postStatus(now)
        } finally {
            scheduleNext()
        }
    }

    private fun scheduleNext() {
        val am = getSystemService(AlarmManager::class.java)
        val pi = PendingIntent.getBroadcast(
            this, 0, Intent(ACT_TICK).setPackage(packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val at = Schedule.nextTriggerMillis()
        if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms())
            am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        else
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
    }

    /** attempt = true kalau kamu sendiri yang membuka game (dihitung sebagai godaan). */
    private fun enforce(pkg: String, attempt: Boolean = true) {
        if (Schedule.isOpen(Schedule.nowSec())) return
        if (pkg in Prefs.blocked(this)) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val t = System.currentTimeMillis()
            if (attempt && t - lastToast > 3000) {
                lastToast = t
                val n = Stats.add(this)
                Toast.makeText(
                    this, "Terkunci. Godaan ke-$n hari ini, dan kamu tetap di jalur.",
                    Toast.LENGTH_SHORT
                ).show()
                Assets.file(this, "voice_TEMPT")?.let { Sfx.play(it) }
            }
        }
    }

    private var lastGuardCheck = 0L

    private fun kickForeground() {
        rootInActiveWindow?.packageName?.toString()?.let { enforce(it, false) }
    }

    /**
     * Mencegah layanan ini dimatikan/dicopot/dihentikan paksa dan jam diubah,
     * kecuali di jendela admin. Hanya memeriksa aplikasi pengaturan/pemasang, dan paling cepat tiap 0,4 detik.
     */
    private fun protectSelf(pkg: String) {
        if (pkg !in SENSITIVE) return
        if (Schedule.inAdmin(Schedule.nowSec())) return
        val t = System.currentTimeMillis()
        if (t - lastGuardCheck < 400) return
        lastGuardCheck = t
        val root = rootInActiveWindow ?: return
        fun has(s: String) = root.findAccessibilityNodeInfosByText(s).isNotEmpty()
        val bad = has("Mengunci game sesuai jadwal") ||                 // halaman layanan aksesibilitas
            (has("Focus Guard") && DANGER.any { has(it) }) ||           // info aplikasi / dialog copot
            (has("Set date") && has("Set time")) ||                     // pengaturan tanggal & jam
            (has("Atur tanggal") && has("Atur waktu"))
        if (bad) {
            performGlobalAction(GLOBAL_ACTION_HOME)
            val a = Schedule.admin
            Toast.makeText(
                this, "Dikunci. Perubahan hanya jam ${Schedule.fmt(a.start)}-${Schedule.fmt(a.end)}.",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    private fun nightGuard() {
        val today = LocalDate.now().toString()
        if (shutdownDay != today) {
            shutdownDay = today
            Thread {
                try {
                    val p = Runtime.getRuntime().exec(arrayOf("su", "-c", "reboot -p"))
                    if (p.waitFor() != 0) failedPowerOff()
                } catch (_: Exception) {
                    failedPowerOff()
                }
            }.start()
        } else if (powerOffFailed) {
            lockIfOn()
        }
    }

    private fun failedPowerOff() {
        powerOffFailed = true
        main.post { lockIfOn() }
    }

    private fun lockIfOn() {
        if (getSystemService(PowerManager::class.java).isInteractive) {
            performGlobalAction(GLOBAL_ACTION_LOCK_SCREEN)
        }
    }

    // ---------- notifikasi ----------

    private val scene by lazy { Scene(this) }

    /** Scene melayang (animasi + musik) -> memudar -> notifikasi + suara. */
    private fun deliver(ev: Schedule.Event) {
        val cheer = Schedule.cheer(ev.kind)
        val focus = if (ev.kind == Schedule.Kind.WORK) Tasks.summary(this) else ""
        val body = if (focus.isEmpty()) cheer else cheer + "\n" + focus
        val interactive = getSystemService(PowerManager::class.java).isInteractive
        if (!interactive) {          // layar mati: cukup notifikasi tanpa suara
            notifyEvent(ev, body)
            return
        }
        scene.play(ev.kind, ev.title, ev.text + "\n" + body) {
            notifyEvent(ev, body)
            val voice = Assets.file(this, "voice_${ev.kind.name}")
            if (voice != null) Sfx.play(voice) else speak(ev, cheer)
        }
    }

    private fun preview(kind: String?) {
        val ev = Schedule.events.firstOrNull { it.kind.name == kind } ?: return
        deliver(ev)
    }

    private fun createChannels() {
        val nm = getSystemService(NotificationManager::class.java)
        for (old in listOf("guard", "rest", "work", "warn")) nm.deleteNotificationChannel(old)
        // Senyap: suara diputar sendiri oleh aplikasi (voice anime atau suara bawaan)
        nm.createNotificationChannel(
            NotificationChannel("rest2", "Istirahat", NotificationManager.IMPORTANCE_DEFAULT).apply {
                setSound(null, null)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel("work2", "Waktu kerja", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel("warn2", "Peringatan", NotificationManager.IMPORTANCE_HIGH).apply {
                setSound(null, null)
                enableVibration(true)
                vibrationPattern = longArrayOf(0, 250, 150, 250)
            }
        )
        nm.createNotificationChannel(
            NotificationChannel("status", "Status", NotificationManager.IMPORTANCE_MIN).apply {
                setShowBadge(false)
            }
        )
    }

    private fun openApp() = PendingIntent.getActivity(
        this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
    )

    /** Hitung mundur ditangani sistem (chronometer): tanpa update dari aplikasi. */
    private fun endMillis(until: Int, now: Int) =
        System.currentTimeMillis() + Schedule.remaining(until, now) * 1000L

    private fun notifyEvent(ev: Schedule.Event, cheer: String) {
        val color = when (ev.kind) {
            Schedule.Kind.REST -> Pal.REST
            Schedule.Kind.WARN -> Pal.WARN
            else -> Pal.WORK
        }
        val channel = when (ev.kind) {
            Schedule.Kind.REST -> "rest2"
            Schedule.Kind.WARN -> "warn2"
            else -> "work2"
        }
        val n = Notification.Builder(this, channel)
            .setSmallIcon(R.drawable.ic_guard)
            .setColor(color)
            .setContentTitle(ev.title)
            .setContentText(ev.text)
            .setStyle(Notification.BigTextStyle().bigText(ev.text + "\n" + cheer))
            .setWhen(endMillis(ev.until, Schedule.nowSec()))
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setContentIntent(openApp())
            .setAutoCancel(true)
            .build()
        getSystemService(NotificationManager::class.java).notify(ev.id.hashCode(), n)
    }

    private fun postStatus(now: Int) {
        val s = Schedule.status(now)
        val n = Notification.Builder(this, "status")
            .setSmallIcon(R.drawable.ic_guard)
            .setColor(if (s.open) Pal.REST else Pal.WORK)
            .setContentTitle(s.label)
            .setContentText(if (s.open) "Game terbuka" else "Game terkunci")
            .setWhen(endMillis(s.untilSec, now))
            .setShowWhen(true)
            .setUsesChronometer(true)
            .setChronometerCountDown(true)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .setContentIntent(openApp())
            .build()
        getSystemService(NotificationManager::class.java).notify(1, n)
    }

    // ---------- suara (TTS bawaan Android, offline, tanpa internet) ----------

    /** Hanya bicara kalau layar menyala. Mesin suara dibuat saat perlu, lalu dilepas. */
    private fun speak(ev: Schedule.Event, cheer: String) {
        if (!getSystemService(PowerManager::class.java).isInteractive) return
        val line = ev.say + " " + cheer
        var engine: TextToSpeech? = null
        engine = TextToSpeech(this) { status ->
            val e = engine
            if (e == null) return@TextToSpeech
            if (status != TextToSpeech.SUCCESS) { e.shutdown(); return@TextToSpeech }
            val id = Locale.forLanguageTag("id-ID")
            if (e.isLanguageAvailable(id) >= TextToSpeech.LANG_AVAILABLE) e.language = id
            e.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build()
            )
            e.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onDone(utteranceId: String?) { e.shutdown() }
                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) { e.shutdown() }
            })
            e.speak(line, TextToSpeech.QUEUE_FLUSH, null, "guard")
        }
    }

    companion object {
        const val ACT_TICK = "com.shim.guard.TICK"
        const val ACT_PREVIEW = "com.shim.guard.PREVIEW"

        private val SENSITIVE = setOf(
            "com.android.settings", "com.miui.securitycenter",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
            "com.miui.packageinstaller", "com.google.android.permissioncontroller",
            "com.android.permissioncontroller"
        )
        private val DANGER = listOf(
            "Force stop", "Paksa berhenti", "Hentikan paksa", "Uninstall", "Copot",
            "Hapus aplikasi", "Clear data", "Hapus data", "Clear storage"
        )
    }
}
