package com.shim.guard

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.view.View

/** Garis 24 jam: mint = game terbuka, abu = terkunci, titik putih = sekarang. Digambar statis. */
class TimelineView(c: Context) : View(c) {

    var nowSec = 0
    private val d = resources.displayMetrics.density
    private val p = Paint(Paint.ANTI_ALIAS_FLAG).apply { strokeCap = Paint.Cap.ROUND }

    override fun onMeasure(w: Int, h: Int) {
        setMeasuredDimension(MeasureSpec.getSize(w), (56 * d).toInt())
    }

    override fun onDraw(c: Canvas) {
        val th = 6 * d
        val w = width.toFloat()
        val y = 18 * d
        fun x(sec: Int) = th / 2 + (w - th) * sec / Schedule.DAY

        p.strokeWidth = th
        p.color = Pal.TRACK
        c.drawLine(x(0), y, x(Schedule.DAY), y, p)

        p.color = Pal.REST
        for (win in Schedule.windows) c.drawLine(x(win.start), y, x(win.end), y, p)

        // penanda HP mati
        p.style = Paint.Style.FILL
        p.color = Pal.WARN
        c.drawCircle(x(Schedule.SHUTDOWN_AT), y, 3 * d, p)

        // sekarang
        p.color = Pal.BG
        c.drawCircle(x(nowSec), y, 9 * d, p)
        p.color = Pal.TXT
        c.drawCircle(x(nowSec), y, 6 * d, p)

        // label jam
        p.textSize = 10 * d
        p.color = Pal.DIM
        p.textAlign = Paint.Align.CENTER
        for (h in intArrayOf(0, 6, 12, 18, 24)) {
            val tx = (x(h * 3600)).coerceIn(10 * d, w - 10 * d)
            c.drawText("%02d".format(h), tx, 46 * d, p)
        }
    }
}
